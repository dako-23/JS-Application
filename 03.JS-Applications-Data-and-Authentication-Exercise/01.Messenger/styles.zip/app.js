function attachEvents() {
    const url = 'http://localhost:3030/jsonstore/messenger';

    const textAreaEl = document.querySelector('#messages');
    const sendBtn = document.querySelector('#submit');
    const refreshBtn = document.querySelector('#refresh');
    const nameAreaEl = document.querySelector('input[name="author"]');
    const messageAreaEl = document.querySelector('input[name="content"]');


    sendBtn.addEventListener('click', postInfo)
    refreshBtn.addEventListener('click', previewNewData)

    function postInfo() {
        if (nameAreaEl.value == '' || messageAreaEl.value == '') return
        fetch(url, {
            method: 'POST',
            body: JSON.stringify({
                author: nameAreaEl.value,
                content: messageAreaEl.value
            }),
            headers: {
                'Content-Type': 'application/json'
            }
        })
            .then(res => res.json())
            .then(data => {
                console.log(data);

                nameAreaEl.value = ''
                messageAreaEl.value = ''
            })
            .catch(err => console.log(err))
    }

    function previewNewData() {

        fetch(url)
            .then(res => res.json())
            .then(data => {

                textAreaEl.textContent = '';
                console.log(data);

                textAreaEl.textContent = Object.values(data).map(({ author, content }) => `${author}: ${content}`).join('\n')
            })
            .catch(err => console.log(err))
    }
}

attachEvents();